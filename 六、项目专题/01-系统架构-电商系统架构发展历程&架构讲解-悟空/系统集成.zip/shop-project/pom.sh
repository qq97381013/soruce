#!/bin/bash -e

pom_g=com.jiagouedu
pom_a=shop-goods
pom_v=1.0-SNAPSHOT
pom_r=snapshots


