package org.pool;

import org.pool.connection.PooledConnection;

/**
 * Description: 对数据库连接池的一个基本管理API接口
 */
public interface IPool {
    public PooledConnection getPooledConnection();
    public void createPooledConnection(int count);
}
