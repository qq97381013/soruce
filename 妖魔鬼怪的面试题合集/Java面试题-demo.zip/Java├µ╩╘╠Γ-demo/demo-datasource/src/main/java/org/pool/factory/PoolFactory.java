package org.pool.factory;

import org.pool.DefaultPool;
import org.pool.IPool;

/**
 * Description:单例模式,连接池工厂
 */
public class PoolFactory {
    public static class CreatePool{
        public static IPool pool = new DefaultPool();
    }

    public static IPool getInstance(){
        return CreatePool.pool;
    }
}
