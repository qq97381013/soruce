package org.pool.conf;

/**
 * Description:数据库配置
 */
public class DBConfig {
    public static final String jdbcDriver = "com.mysql.jdbc.Driver";
    public static final String jdbcUrl = "jdbc:mysql://127.0.0.1:3306/test";
    public static final String jdbcUserName = "root";
    public static final String jdbcPassWord = "123456";
    //数据连接池 初始化大小
    public static final int initCount = 10;
    //连接池不足时，增长时的 步进值
    public static final int step = 2;
    //数据连接池 最大值
    public static final int maxCount = 50;
}
