package org.pool.connection;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;

/**
 * Description:管道
 */
public class PooledConnection {
    private Connection connection;
    private boolean isBusy = false;

    public PooledConnection(Connection connection, boolean isBusy) {
        this.connection = connection;
        this.isBusy = isBusy;
    }

    public boolean isBusy(){
        return isBusy;
    }

    public void setBusy(boolean busy) {
        isBusy = busy;
    }

    public Connection getConnection() {
        return connection;
    }

    public void setConnection(Connection connection) {
        this.connection = connection;
    }

    public void close(){
        this.isBusy = false;
    }

    public ResultSet query(String sql){
        Statement statement;
        ResultSet resultSet = null;
        try{
            statement = connection.createStatement();
            resultSet = statement.executeQuery(sql);
        }catch (Exception e){
            e.printStackTrace();
        }
        return resultSet;
    }
}
