package org.pool.test;

import org.pool.IPool;
import org.pool.connection.PooledConnection;
import org.pool.factory.PoolFactory;

import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * Description:测试 - 手写连接池 - 待扩展
 * 参考：https://www.jianshu.com/p/a50f614571e3
 */
public class DasourceTest {
    public static IPool pool = PoolFactory.getInstance();

    public static void main(String args[]) throws SQLException {
        for(int i=0;i<1000;i++){
            PooledConnection pooledConnection = pool.getPooledConnection();
            ResultSet query = pooledConnection.query("select * from user");
            try{
                while(query.next()){
                    System.out.println(query.getString("username")+"--"+query.getString("age")+"--"+ ++i);
                }
                pooledConnection.close();
            }catch (Exception e){
                e.printStackTrace();
            }
        }
    }
}
