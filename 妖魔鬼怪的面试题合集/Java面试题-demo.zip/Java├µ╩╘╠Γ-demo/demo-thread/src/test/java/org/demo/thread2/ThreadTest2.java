package org.demo.thread2;

import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

/**
 * 两个线程：线程A、线程B，一个固定容量为50的队列List<Integer> list.
 * 线程A不停地产生100以内随机数，判断如果数据不在list中,就将数据加入list中
 * 线程B不停地产生100以内的随机数，判断如果数据存在list中，就从list中删除
 * 
 *  CopyOnWriteArrayList 
 *  只生产和消费50个
 */
public class ThreadTest2 {
	
	static final List<Integer> list = new CopyOnWriteArrayList<Integer>();

	public static void main(String[] args) throws InterruptedException {
		
		Producer producer = new Producer(list);
		Thread A = new Thread(producer);
		A.setName("生产者A");
		
		Consumer consumer = new Consumer(list);
		Thread B = new Thread(consumer);
		B.setName("消费者B");
		
		Thread C = new Thread(new ThreadWatch(list));
		C.setName("监听者C");
		
		A.start();
		B.start();
		C.start();
		
	}
}
