package org.demo.thread1;

import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

import org.demo.thread1.Consumer;
import org.demo.thread1.Producer;
import org.demo.thread1.ThreadWatch;

/**
 * 两个线程：线程A、线程B，一个固定容量为50的队列List<Integer> list.
 * 线程A不停地产生100以内随机数，判断如果数据不在list中,就将数据加入list中
 * 线程B不停地产生100以内的随机数，判断如果数据存在list中，就从list中删除
 * 
 * ReentrantLock CopyOnWriteArrayList 
 * 不断生产和消费
 */
public class ThreadTest {

	static final List<Integer> list = new CopyOnWriteArrayList<Integer>();
    private final static Lock lock = new ReentrantLock(true);
    //Condition
    private final static Condition isNull = lock.newCondition();
    private final static Condition isFull = lock.newCondition();
	
    
	public static void main(String[] args) throws InterruptedException {
		
		Producer producer = new Producer(list,lock,isNull,isFull);
		Thread A = new Thread(producer);
		A.setName("生产者A");
		
//		Thread A1 = new Thread(producer);
//		A1.setName("生产者A1");
		
		Consumer consumer = new Consumer(list,lock,isNull,isFull);
		Thread B = new Thread(consumer);
		B.setName("消费者B");
		
//		Thread B1 = new Thread(consumer);
//		B1.setName("消费者B1");
		
		Thread C = new Thread(new ThreadWatch(list));
		C.setName("监听者C");
		
		A.start();
		B.start();
//		A1.start();
//		B1.start();
		C.start();
	}
}
