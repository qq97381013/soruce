package org.demo.thread1;

import java.util.List;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;
/**
 * 生产者
 */
public class Producer implements Runnable {

	List<Integer> list;
	
	Lock lock;
	Condition isNull;
	Condition isFull;
	
	public Producer(List<Integer> list,Lock lock,Condition isNull,Condition isFull) {
		this.list = list;
		this.lock = lock;
		this.isFull = isFull;
		this.isNull = isNull;
	}
	
	@Override
	public void run() {
		while (true) {
			lock.lock();
			try {
				// 容量到达50，暂停生产，等待消费者消费
				if (list.size() == 50) {
					isFull.await();
					System.out.printf("[%s] - 满了%n", Thread.currentThread().getName());
				}
				// 生成100以内随机数，list中不存在，则新增
				Integer val = (int) (Math.random() * 100 + 1);
				if (!list.contains(val)) {
					list.add(val);
					// 通知消费者，list未空，可以消费了
					isNull.signal();
					System.out.printf("[%s] - 生产[%s]%n", Thread.currentThread().getName(), val);
				} else {
					System.out.printf("[%s] - 已存在[%s]%n", Thread.currentThread().getName(), val);
				}
			} catch (Exception e) {
				e.printStackTrace();
			} finally {
				lock.unlock();
			}
			try {
				Thread.sleep(2000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}

}
