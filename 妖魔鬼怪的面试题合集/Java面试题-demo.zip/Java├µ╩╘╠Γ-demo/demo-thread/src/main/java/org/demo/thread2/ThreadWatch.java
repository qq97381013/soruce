package org.demo.thread2;

import java.util.List;
/**
 * 监听者
 */
public class ThreadWatch implements Runnable {

	List<Integer> list;
	
	public ThreadWatch(List<Integer> list) {
		this.list = list;
	}
	
	@Override
	public void run() {
		while(true) {
			System.out.printf("[%s] - 监听 - list.size[%s],list%s%n", Thread.currentThread().getName(),list.size(),list);
			try {
				Thread.sleep(5000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			if(list.size()==0) {
				break;
			}
		}
		
	}

}
