package org.demo.thread1;

import java.util.List;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;

/**
 * 消费者
 */
public class Consumer implements Runnable {

	List<Integer> list;
	
	Lock lock;
	Condition isNull;
	Condition isFull;
	
	public Consumer(List<Integer> list,Lock lock,Condition isNull,Condition isFull) {
		this.list = list;
		this.lock = lock;
		this.isFull = isFull;
		this.isNull = isNull;
	}
	
	@Override
	public void run() {
		while(true) {
			lock.lock();
			try {
				// 容量不足，暂停消费，等待生产者生产
				if(list.size()==0) {
					isNull.await();
					System.out.printf("[%s] - 空了%n", Thread.currentThread().getName());
				}
				// 生成100以内随机数，list中存在，则删除
				Integer val = (int) (Math.random()*100+1);
				if(list.contains(val)) {
					list.remove(val);
					// 知道生产者，list没有满，可以继续生产了
					isFull.signal();
					System.out.printf("[%s] - 消费[%s]%n", Thread.currentThread().getName(),val);
				}
			} catch (Exception e) {
				e.printStackTrace();
			} finally {
				lock.unlock();
			}
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		
	}
}
