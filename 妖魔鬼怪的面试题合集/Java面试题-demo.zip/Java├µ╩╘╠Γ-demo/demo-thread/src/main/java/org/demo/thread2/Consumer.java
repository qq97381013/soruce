package org.demo.thread2;

import java.util.List;

/**
 * 消费者 
 */
public class Consumer implements Runnable {

	List<Integer> list;
	
	public Consumer(List<Integer> list) {
		this.list = list;
	}
	
	public void run() {
		while(true) {
			Integer val = (int) (Math.random()*100+1);
			if(list.contains(val)) {
				list.remove(val);
				System.out.printf("[%s] - 消费[%s]%n", Thread.currentThread().getName(),val);
			}
			try {
				Thread.sleep(500);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			//消费完成，自动退出
			if(list.size()==0) {
				System.out.printf("[%s] - 消费完成%n", Thread.currentThread().getName());
				break;
			}
		}
		
	}
}
