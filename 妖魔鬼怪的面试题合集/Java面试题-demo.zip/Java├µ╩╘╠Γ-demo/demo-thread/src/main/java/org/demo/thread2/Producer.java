package org.demo.thread2;

import java.util.List;
/**
 * 生产者 
 */
public class Producer implements Runnable {

	List<Integer> list;
	
	boolean isrunning;
	
	public Producer(List<Integer> list) {
		this.list = list;
		this.isrunning = true;
	}
	
	public boolean isRunning() {
		return isrunning;
	}
	
	public void run() {
		while(true) {
			Integer val = (int) (Math.random()*100+1);
			if(!list.contains(val)) {
				list.add(val);
				System.out.printf("[%s] - 生产[%s]%n", Thread.currentThread().getName(),val);
			}else {
				System.out.printf("[%s] - 已存在[%s]%n", Thread.currentThread().getName(),val);
			}
			try {
				Thread.sleep(500);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			//生产完成，停止生产
			if(list.size() == 50) {
				System.out.printf("[%s] - 生产完成[%s]%n", Thread.currentThread().getName());
				break;
			}
		}
		isrunning = false;
	}

	

}
