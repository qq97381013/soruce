package org.demo.linkedlist;

/**
 * 测试 - 手写LinkedList,实现add和remove
 */
public class MyLinkedList1Test {

	public static void main(String[] args) {
		MyLinkedList1 list = new MyLinkedList1();
		list.add("a");
		list.add("b");
		list.add("c");
		list.add("d");
		System.out.println(list);
		list.remove(3);
		System.out.println(list);
		
	}
}
