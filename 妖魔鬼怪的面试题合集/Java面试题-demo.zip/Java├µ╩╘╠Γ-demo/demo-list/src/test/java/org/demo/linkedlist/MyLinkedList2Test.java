package org.demo.linkedlist;
/**
 * 测试 - 手写LinkedList,实现add和remove
 */
public class MyLinkedList2Test {

	public static void main(String[] args) {
		MyLinkedList2<String> list = new MyLinkedList2<String>();
		list.add("b");
		list.add(null);
		list.add("a");
		list.add(null);
		list.add("a");
		list.add("c");
		System.out.println(list);
		System.out.println(list.removeAndCount("a"));
		System.out.println(list.removeAndCount(null));
		System.out.println(list);
	}
}
