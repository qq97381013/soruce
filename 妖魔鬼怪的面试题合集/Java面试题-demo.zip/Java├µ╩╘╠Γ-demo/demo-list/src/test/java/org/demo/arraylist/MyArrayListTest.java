package org.demo.arraylist;
/**
 * 测试 - 手写ArrayList,实现add和remove
 */
public class MyArrayListTest {
	
	public static void main(String[] args) {
		MyArrayList list = new MyArrayList(10);
		list.add("a");
		list.add("b");
		list.add("c");
		list.add("a");
		list.add("d");
		list.add("e");
		list.add(3, "k");
		System.out.println(list);
		list.remove("c");
		list.remove("a");
		System.out.println(list);
	}
}
