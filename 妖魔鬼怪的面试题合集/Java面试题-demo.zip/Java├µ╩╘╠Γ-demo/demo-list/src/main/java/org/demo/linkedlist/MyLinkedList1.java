package org.demo.linkedlist;

/**
 * 手写双向链表1
 * 参考：https://www.cnblogs.com/hkblogs/p/9117249.html
 */
public class MyLinkedList1 {

	Node first;// 第一个节点
	Node last;// 最后一个节点

	private int size = 0;

	public MyLinkedList1() {
	}

	public int size() {
		return size;
	}

	public MyLinkedList1(Node first, Node last) {
		super();
		this.first = first;
		this.last = last;
	}

	// 往链表的末尾新增一个元素
	public boolean add(Object obj) {
		Node n = new Node();
		if (null == first) {
			n.prev = null;
			n.obj = obj;
			n.next = null;
			first = n;
			last = n;
		} else {
			n.prev = last;
			n.obj = obj;
			n.next = null;
			last.next = n;
			last = n;
		}
		size++;
		return true;
	}

	public Object get(int index) {
		Node temp = findNode(index);
		return temp.obj;
	}

	public Object remove(int index) {
		Node temp = findNode(index);
		if (temp.prev == null) {
			first = temp.next;
		} else {
			temp.prev.next = temp.next;
			temp.prev = null;
		}
		if (temp.next == null) {
			last = temp.prev;
		} else {
			temp.next.prev = temp.prev;
			temp.next = null;
		}
		size--;
		return temp.obj;
	}

	private Node findNode(int index) {
		if(index <0 || index >size - 1){
			throw new RuntimeException("索引數字不合法："+index);
		}
		Node temp = null;
		if (first != null) {
			temp = first;
			for (int i = 0; i < index; i++) {
				temp = temp.next;
			}
		}
		return temp;
	}

	static class Node {
		Node prev;// 上一个节点信息
		Object obj;// 实际存储的对象
		Node next;// 下一个节点信息

		public Node() {
		}

	}
	
	@Override
	public String toString() {
		StringBuffer buffer = new StringBuffer();
		Node temp = null;
		if (first != null) {
			buffer.append("[");
			temp = first;
			buffer.append(temp.obj);
			while(null != temp.next) {
				temp = temp.next;
				buffer.append(",").append(temp.obj);
			}
			buffer.append("]");
		}
		return buffer.toString();
	}
	
	

}