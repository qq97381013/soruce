package org.demo.arraylist;

import java.util.Arrays;
/**
 * 手写ArrayList
 * 参考：https://www.cnblogs.com/hkblogs/p/9025221.html
 * 
 * 待处理：删除操作，空元素未回收
 */
public class MyArrayList {

    private  Object[] elementData;
    private int size;
    
    //构造器
    public MyArrayList(int size){
        this.elementData=new Object[size];
    }
    
    public int size(){
        return size;
    }
    
    public boolean add(Object o){
        ensureCapacityInternal(size+1);
        elementData[size++]=o;
        return true;
    }
    
    //重载add方法通过下标来添加
    public boolean add(int index,Object o){
        rangeCheck(index);
        ensureCapacityInternal(size+1);
        System.arraycopy(elementData, index, elementData, index+1, size-index);
        elementData[index]=o;
        size++;
        return true;
    }
    
    // 删除元素
    public void remove(Object o) {
    	for(int i=0;i<size;i++) {
    		if(o.equals(elementData[i])) {
    			//删除
    			System.arraycopy(elementData,i+1,elementData,i,size-i-1);
    			elementData[--size] = null;//问题:空元素未回收
    		}
    	}
    }
    
    public Object get(int index) {
        rangeCheck(index);
        return elementData[index];
    }
    
    //检查给定下标是否符合规则
    private void rangeCheck(int index){
        if(index>size||index<0){
            throw new IndexOutOfBoundsException("下标有误，Index:"+index+",size:"+size);
        }
    }
    
    public Object set(int index,Object element) {
        rangeCheck(index);
        Object oldValue = elementData[index];
        elementData[index] = element;
        return oldValue;
    }
    
    private void ensureCapacityInternal(int minCapacity) {
        if (minCapacity - elementData.length > 0){
            //需要的最小容量已经大于了数组的长度，此时需要扩容
            int oldCapacity=elementData.length;
            int newCapacity=(oldCapacity*3)/2;
            //如果扩容1.5倍还不够，则将传入的长度为新长度
            if (newCapacity - minCapacity < 0)
                newCapacity=minCapacity;
            elementData=Arrays.copyOf(elementData, newCapacity);
        }
    }

    @Override
    public String toString() {
        return "MyArrayList [elementData=" + Arrays.toString(elementData) + ", size=" + size + "]";
    }
    

}