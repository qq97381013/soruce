package org.demo.linkedlist;

/**
 * 手写双向链表2
 * 待扩展 - removeAndCount，只删除了第一次出现的元素 
 */
public class MyLinkedList2<E> {

	Node<E> first;// 首指针
	Node<E> last;// 尾指针

	private int size = 0;//容量

	public int size() {
		return size;
	}

	// 往链表的末尾新增一个元素
	public boolean add(E e) {
		final Node<E> l = last;
		Node<E> newNode = new Node<E>(l, e, null);
        last = newNode;
        if (l == null) {
            first = newNode;
        }else {
            l.next = newNode;
        }
        size++;
		return true;
	}
	
	//移除节点 - 待扩展，需删除所有匹配元素，并返回匹配数量
	public boolean removeAndCount(E e) {
		//int count = 0;
		if (e == null) {
            for (Node<E> x = first; x != null; x = x.next) {
                if (x.item == null) {
                	unlink(x);
                    //count++;
                	return true;
                }
            }
        } else {
            for (Node<E> x = first; x != null; x = x.next) {
                if (e.equals(x.item)) {
                	unlink(x);
                    //count++;
                	return true;
                }
            }
        }
        //return count;
		return false;
	}
	
	// 获取节点对象
	public Object get(int index) {
		Node<E> temp = findNode(index);
		return temp.item;
	}
	
	//删除节点
	E unlink(Node<E> x) {
		//缓存节点
		final E element = x.item;
        final Node<E> next = x.next;
        final Node<E> prev = x.prev;
        if (prev == null) {
        	//前面没有节点，首指针指向下一个节点
            first = next;
        } else {
        	//上一个节点指向下一个节点
            prev.next = next;
            //删除当前节点也上一个节点的关联
            x.prev = null;
        }
        if (next == null) {
        	//后面没有节点，尾指针指向上一个节点
            last = prev;
        } else {
        	//下一个节点指向上一个节点
            next.prev = prev;
            //删除当前节点与下一个节点的关联
            x.next = null;
        }
        x.item = null;
        size--;
        return element;
    }
	

	//移除节点
	//相对ArrayList会快，因为ArrayList要移动数据而LinkedList只需要移动指针
	public Object remove(int index) {
		//查找节点
		Node<E> x = findNode(index);
		//删除节点
		return unlink(x);
	}

	
	//查询节点
	//相对ArrayList会慢，因为LinkedList要移动指针
	private Node<E> findNode(int index) {
		if(index <0 || index > size - 1){
			throw new RuntimeException("索引數字不合法："+index);
		}
		Node<E> temp = null;
		if (first != null) {
			temp = first;
			for (int i = 0; i < index; i++) {
				temp = temp.next;
			}
		}
		return temp;
	}

	//节点对象
    private static class Node<E> {
        E item;//存储的对象
        Node<E> next;//上一个节点
        Node<E> prev;//下一个节点

        Node(Node<E> prev, E element, Node<E> next) {
            this.item = element;
            this.next = next;
            this.prev = prev;
        }
    }

	@Override
	public String toString() {
		StringBuffer buffer = new StringBuffer();
		Node<E> temp = null;
		if (first != null) {
			buffer.append("[");
			temp = first;
			buffer.append(temp.item);
			while(null != temp.next) {
				temp = temp.next;
				buffer.append(",").append(temp.item);
			}
			buffer.append("]");
		}
		return buffer.toString();
	}
	

}