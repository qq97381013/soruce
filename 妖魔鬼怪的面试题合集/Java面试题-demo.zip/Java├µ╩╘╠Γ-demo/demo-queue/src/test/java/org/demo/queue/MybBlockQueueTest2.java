package org.demo.queue;

import java.util.concurrent.TimeUnit;

/**
 * 测试 - 手写阻塞队列 - 实现 put take offer poll
 */
public class MybBlockQueueTest2 {

	
	public static void main(String[] args) {
		
	    MyBlockQueue2<Object> queue = new MyBlockQueue2<Object>(5);
	    
	    putAndTake(queue);//Exception in thread "Thread-1" java.lang.IllegalMonitorStateException
	    
	    offerAndpoll(queue);//Exception in thread "Thread-3" java.lang.ArrayIndexOutOfBoundsException: 0
	    
	}

	private static void offerAndpoll(MyBlockQueue2<Object> queue) {
		Thread t3 = new Thread(() -> {
	        for (int i = 0; i < 50; i++) {
	            try {
					queue.offer(i, 1, TimeUnit.SECONDS);
					System.out.printf("[%s] - 生产%s%n",Thread.currentThread().getName(),i);
					Thread.sleep(50);
				} catch (InterruptedException e1) {
					e1.printStackTrace();
				}
	        }
	    });
	    Thread t4 = new Thread(() -> {
	    	 for (int i = 0; i < 50; i++) {
	            try {
	            	System.out.printf("[%s] - 消费%s%n",Thread.currentThread().getName(),queue.poll(1, TimeUnit.SECONDS));
	                Thread.sleep(50);
	            } catch (InterruptedException e) {
	                e.printStackTrace();
	            }
	        }

	    });
	    t3.start();
	    t4.start();
		
	}

	private static void putAndTake(MyBlockQueue2<Object> queue) {
		Thread t1 = new Thread(() -> {
	        for (int i = 0; i < 50; i++) {
	            queue.put(i);
	            System.out.printf("[%s] - 生产%s%n",Thread.currentThread().getName(),i);
	            try {
	                Thread.sleep(50);
	            } catch (InterruptedException e) {
	                e.printStackTrace();
	            }
	        }
	    });
	    Thread t2 = new Thread(() -> {
	        for (;;) {
	        	System.out.printf("[%s] - 消费%s%n",Thread.currentThread().getName(),queue.take());
	            try {
	                Thread.sleep(50);
	            } catch (InterruptedException e) {
	                e.printStackTrace();
	            }
	        }

	    });
	    t1.start();
	    t2.start();
	}
}
