package org.demo.queue;

import java.util.concurrent.TimeUnit;

/**
 * 测试 - 手写阻塞队列 - 实现 put take offer poll
 */
public class MybBlockQueueTest {

	
	public static void main(String[] args) {
		
	    MyBlockQueue<Object> queue = new MyBlockQueue<Object>(5);
	    
	    // 1.test put take
	    putAndTake(queue);
	    
	    // 2.test offer(timeout) poll(timeout)
	    offerTimeAndpollTime(queue,1, TimeUnit.MICROSECONDS);
	    
	    // 3.test offer() poll()
	    offerAndpoll(queue);
	    
	}

	private static void offerAndpoll(MyBlockQueue<Object> queue) {
		Thread t5 = new Thread(() -> {
	        for (int i = 0; i < 50; i++) {
	            try {
					queue.offer(i);
					System.out.printf("[%s] - 生产%s%n",Thread.currentThread().getName(),i);
					Thread.sleep(50);
				} catch (InterruptedException e1) {
					e1.printStackTrace();
				}
	        }
	    });
	    Thread t6 = new Thread(() -> {
	    	 for (int i = 0; i < 50; i++) {
	            try {
	            	System.out.printf("[%s] - 消费%s%n",Thread.currentThread().getName(),queue.poll());
	                Thread.sleep(50);
	            } catch (InterruptedException e) {
	                e.printStackTrace();
	            }
	        }

	    });
	    t5.start();
	    t6.start();
		
	}

	private static void offerTimeAndpollTime(MyBlockQueue<Object> queue,long timeout, TimeUnit unit) {
		Thread t3 = new Thread(() -> {
	        for (int i = 0; i < 50; i++) {
	            try {
					queue.offer(i, timeout, unit);
					System.out.printf("[%s] - 生产%s%n",Thread.currentThread().getName(),i);
					Thread.sleep(50);
				} catch (InterruptedException e1) {
					e1.printStackTrace();
				}
	        }
	    });
	    Thread t4 = new Thread(() -> {
	    	 for (int i = 0; i < 50; i++) {
	            try {
	            	System.out.printf("[%s] - 消费%s%n",Thread.currentThread().getName(),queue.poll(timeout, unit));
	                Thread.sleep(50);
	            } catch (InterruptedException e) {
	                e.printStackTrace();
	            }
	        }

	    });
	    t3.start();
	    t4.start();
	}

	private static void putAndTake(MyBlockQueue<Object> queue) {
		Thread t1 = new Thread(() -> {
	        for (int i = 0; i < 50; i++) {
	            queue.put(i);
	            System.out.printf("[%s] - 生产%s%n",Thread.currentThread().getName(),i);
	            try {
	                Thread.sleep(50);
	            } catch (InterruptedException e) {
	                e.printStackTrace();
	            }
	        }
	    });
	    Thread t2 = new Thread(() -> {
	        for (;;) {
	        	System.out.printf("[%s] - 消费%s%n",Thread.currentThread().getName(),queue.take());
	            try {
	                Thread.sleep(50);
	            } catch (InterruptedException e) {
	                e.printStackTrace();
	            }
	        }

	    });
	    t1.start();
	    t2.start();
	}
}
