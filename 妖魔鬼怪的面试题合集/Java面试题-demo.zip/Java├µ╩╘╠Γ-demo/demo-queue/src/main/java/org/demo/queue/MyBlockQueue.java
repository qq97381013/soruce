package org.demo.queue;

import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

/**
 * 自行实现一个阻塞队列
 * int size
 */
public class MyBlockQueue<E> {
	
	//队列容器
    private List<E> container = new CopyOnWriteArrayList<E>();
    
    //队列已使用容量
    private volatile int size;
    
    //队列容量
    private volatile int capacity;
    
    private Lock lock = new ReentrantLock(false);
    
    //Condition
    private final Condition isNull = lock.newCondition();
    private final Condition isFull = lock.newCondition();

    MyBlockQueue(int capacity) {
    	if (capacity <= 0) {
			throw new IllegalArgumentException("队列大小需大于0");
		}	
        this.capacity = capacity;
    }
    
    //添加元素
    public boolean offer(E e, long timeout, TimeUnit unit)
            throws InterruptedException {
        checkNotNull(e);
        long nanos = unit.toNanos(timeout);
        lock.lockInterruptibly();
        try {
            while (size == capacity) {
                if (nanos <= 0) {
                    return false;
                }
                nanos = isFull.awaitNanos(nanos);
                System.out.printf("阻塞队列满了，阻塞%s納秒%n",nanos);
            }
            enqueue(e);
            return true;
        } finally {
            lock.unlock();
        }
    }
    
    //添加元素
    public boolean offer(E e)
            throws InterruptedException {
        checkNotNull(e);
        lock.lockInterruptibly();
        try {
            while (size == capacity) {
                isFull.await();
                System.out.printf("阻塞队列满了%n");
            }
            enqueue(e);
            return true;
        } finally {
            lock.unlock();
        }
    }
    
    //取出元素
    public E poll(long timeout, TimeUnit unit)
            throws InterruptedException {
        long nanos = unit.toNanos(timeout);
        lock.lockInterruptibly();
        try {
            while (size == 0) {
                if (nanos <= 0) {
                    return null;
                }
                nanos = isNull.awaitNanos(nanos);
                System.out.printf("阻塞队列空了，阻塞%s納秒%n",nanos);
            }
            return dequeue();
        } finally {
            lock.unlock();
        }
    }
    
    //取出元素
    public E poll() throws InterruptedException {
        lock.lockInterruptibly();
        try {
            while (size == 0) {
                isNull.await();
                System.out.printf("阻塞队列空了%n");
            }
            return dequeue();
        } finally {
            lock.unlock();
        }
    }

    //添加元素
    public void put(E e) {
        try {
        	checkNotNull(e);
            lock.lock();
            try {
                while (size >= capacity) {
                    System.out.println("阻塞队列满了");
                    isFull.await();
                }
            } catch (InterruptedException e1) {
                isFull.signal();
                e1.printStackTrace();
            }
            enqueue(e);
        } finally {
            lock.unlock();
        }
    }

    //取出元素
    public E take() {
        try {
            lock.lock();
            try {
                while (size == 0) {
                    System.out.println("阻塞队列空了");
                    isNull.await();
                }
            } catch (InterruptedException e) {
                isNull.signal();
                e.printStackTrace();
            }
            return dequeue();
        } finally {
            lock.unlock();
        }
    }
    
    //校验元素
	private void checkNotNull(E e) {
		if (null == e) {
			throw new NullPointerException();
		}	
	}
	
	//添加元素
	private void enqueue(E e) {
		size++;
		container.add(e);
		isNull.signal();
	}
	
	//获取元素
	private E dequeue() {
		size--;
		E res = container.get(0);
		container.remove(0);
		isFull.signal();
		return res;
	}
}
