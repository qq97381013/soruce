namespace java com.tulin.thrift

typedef i32 int // We can use typedef to get pretty names for the types we are using

struct SimpleBeanThrift {
  1: i32    ID;
  2: string Url;
  3: list<string> name;
}
struct SimpleBeanThriftId {
  1: string    id
}
service EmployeeService {
  SimpleBeanThrift getEmployee(1:SimpleBeanThrift id)
}
