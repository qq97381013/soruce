/**
 * Created by Administrator on 2018/8/5.
 */

/**
 * @author Tommy
 *         Created by Tommy on 2018/8/5
 **/
public class Luban {
    public static void main(String[] args) {
        System.out.println("hello luban");
    }
}
