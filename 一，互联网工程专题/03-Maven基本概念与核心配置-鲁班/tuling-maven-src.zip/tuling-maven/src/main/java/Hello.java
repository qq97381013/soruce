package com.tuling;
public class Hello {
	public String sayHello(String name){
		return name;
	}

}
