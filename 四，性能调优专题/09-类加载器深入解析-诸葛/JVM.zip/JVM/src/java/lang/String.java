package java.lang;

/**
 * Created by ���  on 2018/9/26.
 */
public class String {

    public static void main(String[] args){
        System.out.println("*************My String Class************");
    }
}
